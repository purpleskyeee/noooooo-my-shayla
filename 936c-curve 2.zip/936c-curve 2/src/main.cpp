/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       Richard Wang (1698V)                                      */
/*    Created:      July 9, 2023                                              */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#include "vex.h"
#include "motor-control.h"
#include "math.h"
#include "../custom/include/autonomous.h"
#include "../custom/include/user.h"
#include "../custom/include/robot-config.h"
#include "threads.h"
using namespace vex;

// A global instance of competition
competition Competition;

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  runPreAutonomous();
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*                                                                           */
/*-------------------------------
--------------------------------------------*/

void autonomous(void) {
  runAutonomous();
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  runDriver();
}

vex::thread intakeThread(intakeThreadMain);
vex::thread tongueThread(tongueThreadMain);

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // // Set up callbacks for autonomous and driver control periods.
  //Competition.autonomous(autonomous);
  // Competition.drivercontrol(usercontrol);
  // tonguemech.open();
  // wait(10,sec);
  // tonguemech.close();
  // Run the pre-autonomous function.
  pre_auton();
  wait(100, msec);
  autonomous();;
  driveTo(33, 2000, true, 12, 0, true);
  turnToAngle(-45, 2000, true, 12);
  driveTo(1, 500, true, 8, 0, true);
  hood_dir = true;
  intake_dir=true;
  intake_running=true;
  wait(2500, msec);

  intake_running=false;
  hood_dir = true;
  intake_dir=false;

  driveTo(4, 500, true, 8, 0, true);
  driveTo(-46, 2000, true, 12, 0, true);
  turnToAngle(-180, 2000, true, 12);
  tongue_running=true;
  wait(10000, msec);

  while (true) {
    wait(100, msec);
  }
}

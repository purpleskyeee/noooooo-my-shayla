#ifndef THREADS_CPP
#define THREADS_CPP
#include <vex.h>
#include <motor-control.h>
#include <iostream>

bool intake_running = false;
bool intake_dir = false; //true = rev
bool hood_dir = false; 

bool tongue_running = false; //down?
bool tongue_changed = false; //last state


int intakeThreadMain() 
{
  while (1) {
    if(intake_running){
        bool reverse = intake_dir;
        vex::directionType hoodDir = hood_dir ? vex::directionType::rev : vex::directionType::fwd;
        vex::directionType intakeDir = reverse ? vex::directionType::rev : vex::directionType::fwd;
        
        hoodMotor.spin(hoodDir, 12.8, vex::voltageUnits::volt);
        intakeMotor.spin(intakeDir, 12.8, vex::voltageUnits::volt);
    }
    vex::wait(50, vex::msec);
  }
  return 0;
}

int tongueThreadMain() 
{
  while (1) {
    if(tongue_running&&!tongue_changed)
    {
      tongue_changed=true;
      tonguemech.close();
      std::cout<<"tongue closed"<<std::endl;
    }
    else if(!tongue_running&&tongue_changed)
    {
      tongue_changed=false;
      tonguemech.open();
        std::cout<<"tongue opened"<<std::endl;
    }
    vex::wait(50, vex::msec);
  }
  return 0;
}

#endif // THREADS_CPP
#ifndef THREADS_H
#define THREADS_H
#include "vex.h"
#include "motor-control.h"

extern bool intake_running;
extern bool intake_dir;
extern bool hood_dir;

extern bool tongue_running;
extern bool tongue_changed;

double clampIntakeVoltage(double volts);
int intakeThreadMain();
int tongueThreadMain();
#endif // THREADS_H
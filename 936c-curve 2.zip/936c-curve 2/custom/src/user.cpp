#include "vex.h"
#include "motor-control.h"
#include "../custom/include/autonomous.h"

// Modify autonomous, driver, or pre-auton code below

void runAutonomous() {
  captureReferenceWallsFromSensors(8);
  int auton_selected = 3;
  switch(auton_selected) {
    case 1:
      break;
    case 2:
      break;  
    case 3:
      break;
    case 4:
      break; 
    case 5:
      break;
    case 6:
      break;
    case 7:
      break;
    case 8:
      break;
    case 9:
      break;
  }
}

// controller_1 input variables (snake_case)
int ch1, ch2, ch3, ch4;
bool l1, l2, r1, r2;
bool button_a, button_b, button_x, button_y;
bool button_up_arrow, button_down_arrow, button_left_arrow, button_right_arrow;
int chassis_flag = 0;
int MAXVELOCITY = 12800;

double axis3 = 0;
double axis1 = 0;
double Right_Power = 0;
double Left_Power = 0;
bool lasttonguepressstate = false;
bool lastbandpressstate = false;
bool lastdescorepressstate = false;
bool lastsiddescorestate = false;
bool lastdefensestate = false;
bool tonguemechdown = false;
bool rubberbandon = false;
bool middescoreon = false;
bool descoreup = false;
int defensechange = 1;

void runDriver() {
  stopChassis(coast);
  heading_correction = false;
  while (true) {
    ch1 = controller_1.Axis1.value();
    ch2 = controller_1.Axis2.value();
    ch3 = controller_1.Axis3.value();
    ch4 = controller_1.Axis4.value();

    l1 = controller_1.ButtonL1.pressing();
    l2 = controller_1.ButtonL2.pressing();
    r1 = controller_1.ButtonR1.pressing();
    r2 = controller_1.ButtonR2.pressing();
    button_a = controller_1.ButtonA.pressing();
    button_b = controller_1.ButtonB.pressing();
    button_x = controller_1.ButtonX.pressing();
    button_y = controller_1.ButtonY.pressing();
    button_up_arrow = controller_1.ButtonUp.pressing();
    button_down_arrow = controller_1.ButtonDown.pressing();
    button_left_arrow = controller_1.ButtonLeft.pressing();
    button_right_arrow = controller_1.ButtonRight.pressing();

    bool intakebutnoscore = controller_1.ButtonR1.pressing();
    bool score = controller_1.ButtonR2.pressing();
    bool tonguemechtoggle = controller_1.ButtonL2.pressing();
    bool outtake = controller_1.ButtonL1.pressing();

    bool rubberbandtoggle = controller_1.ButtonY.pressing();
    bool middescoretoggle = controller_1.ButtonRight.pressing();
    bool sidedescoretoggle = controller_1.ButtonDown.pressing();
    bool defensing = controller_1.ButtonA.pressing();

    axis3 = controller_1.Axis3.position();
    axis1 = controller_1.Axis1.position();
    Right_Power = axis3 - defensechange * axis1;
    Left_Power = axis3 + defensechange * axis1;
    if (Right_Power > 128) Right_Power = 128;
    if (Right_Power < -128) Right_Power = -128;
    if (Left_Power > 128) Left_Power = 128;
    if (Left_Power < -128) Left_Power = -128;

    if (intakebutnoscore) {
      hoodMotor.spin(vex::directionType::rev, MAXVELOCITY, vex::voltageUnits::mV);
      intakeMotor.spin(vex::directionType::fwd, MAXVELOCITY, vex::voltageUnits::mV);
    } else if (score) {
      hoodMotor.spin(vex::directionType::fwd, MAXVELOCITY, vex::voltageUnits::mV);
      intakeMotor.spin(vex::directionType::fwd, MAXVELOCITY, vex::voltageUnits::mV);
    } else if (outtake) {
      hoodMotor.spin(vex::directionType::rev, MAXVELOCITY, vex::voltageUnits::mV);
      intakeMotor.spin(vex::directionType::rev, MAXVELOCITY, vex::voltageUnits::mV);
    } else {
      hoodMotor.stop();
      intakeMotor.stop();
    }

    if (tonguemechtoggle != lasttonguepressstate) { //hold
      tonguemechdown = !tonguemechdown;
    }

    if (rubberbandtoggle != lastbandpressstate&&lastbandpressstate==false) { //trigger
      rubberbandon = !rubberbandon;
    }

    if (middescoretoggle != lastdescorepressstate&&lastdescorepressstate==false) { //trigger
      middescoreon = !middescoreon;
    }

    if (sidedescoretoggle != lastsiddescorestate&&lastsiddescorestate==false) { //trigger
      descoreup = !descoreup;
    }

    if (defensing != lastdefensestate&&lastdefensestate==false) { //trigger
      defensechange *= -1;
    }

    lasttonguepressstate = tonguemechtoggle;
    lastbandpressstate = rubberbandtoggle;
    lastdescorepressstate = middescoretoggle;
    lastsiddescorestate = sidedescoretoggle;
    lastdefensestate = defensing;

    if (tonguemechdown) tonguemech.set(true);
    else tonguemech.set(false);

    if (rubberbandon) rubberband.set(false);
    else rubberband.set(true);

    if (middescoreon) middescore.set(true);
    else middescore.set(false);

    if (descoreup) sidedescore.set(true);
    else sidedescore.set(false);

    left_chassis.spin(vex::directionType::fwd, 128 * defensechange * Left_Power, vex::voltageUnits::mV);
    right_chassis.spin(vex::directionType::fwd, 128 * defensechange * Right_Power, vex::voltageUnits::mV);

    wait(10, msec);
  }
}

void runPreAutonomous() {
    // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  // Calibrate inertial sensor
  inertial_sensor.calibrate();

  // Wait for the Inertial Sensor to calibrate
  while (inertial_sensor.isCalibrating()) {
    wait(10, msec);
  }

  double current_heading = inertial_sensor.heading();
  Brain.Screen.print(current_heading);
  
  // odom tracking
  resetChassis();
  if(using_horizontal_tracker && using_vertical_tracker) {
    thread odom = thread(trackXYOdomWheel);
  } else if (using_horizontal_tracker) {
    thread odom = thread(trackXOdomWheel);
  } else if (using_vertical_tracker) {
    thread odom = thread(trackYOdomWheel);
  } else {
    thread odom = thread(trackNoOdomWheel);
  }

  shutdownIndexer();
}
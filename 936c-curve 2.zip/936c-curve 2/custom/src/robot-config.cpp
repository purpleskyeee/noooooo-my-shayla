#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
controller controller_1 = controller(primary);

// IMPORTANT: Remember to modify the example motors according to the guide. 
// Also remember to add respective device declarations to custom/include/robot-config.h
// Format: motor(port, gearSetting, reversed)
// gearSetting is one of the following: ratio36_1(red), ratio18_1(green), ratio6_1(blue)
// all chassis motors should be reversed appropriately so that they spin vertical when given a positive voltage input
// such as driveChassis(12, 12)
motor left_chassis1 = motor(PORT12, ratio6_1, true);
motor left_chassis2 = motor(PORT11, ratio6_1, true);
motor left_chassis3 = motor(PORT16, ratio6_1, true);
motor_group left_chassis = motor_group(left_chassis1, left_chassis2, left_chassis3);
motor right_chassis1 = motor(PORT19, ratio6_1, false);
motor right_chassis2 = motor(PORT17, ratio6_1, false);
motor right_chassis3 = motor(PORT18, ratio6_1, false);
motor_group right_chassis = motor_group(right_chassis1, right_chassis2, right_chassis3);

inertial inertial_sensor = inertial(PORT20);
motor intakeMotor = motor(PORT10, ratio6_1, false);
motor hoodMotor = motor(PORT9, ratio6_1, false);
pneumatics tonguemech = pneumatics(Brain.ThreeWirePort.B);
pneumatics rubberband = pneumatics(Brain.ThreeWirePort.C);
pneumatics middescore = pneumatics(Brain.ThreeWirePort.E);
pneumatics sidedescore = pneumatics(Brain.ThreeWirePort.F);

// Format is rotation(port, reversed)
// just set these to random ports if you don't use tracking wheels
rotation horizontal_tracker = rotation(PORT1, true);
rotation vertical_tracker = rotation(PORT1, true);

// game specific devices for high stakes
motor arm_motor1 = motor(PORT1, ratio18_1, true);
motor arm_motor2 = motor(PORT1, ratio18_1, false);
motor_group arm_motor = motor_group(arm_motor1, arm_motor2);
motor intake_motor = motor(PORT1, ratio18_1, true);
motor &intake_primary_motor = intake_motor;
motor &intake_stage1_motor = intake_motor;
motor &intake_stage2_motor = intake_motor;
digital_out claw = digital_out(Brain.ThreeWirePort.F);
digital_out rush_arm = digital_out(Brain.ThreeWirePort.G);
optical optical_sensor = optical(PORT1);
distance intake_distance = distance(PORT1);
distance clamp_distance = distance(PORT1);
distance storage_distance_sensor = distance(PORT1);
distance middle_goal_scoring_sensor = distance(PORT1);
distance long_goal_scoring_sensor = distance(PORT1);
distance &top_distance_sensor = long_goal_scoring_sensor;
// Provide friendly aliases expected by motor-control correction code
// These are references to the actual sensor objects above.
distance &front_distance = intake_distance;
distance &right_distance = clamp_distance;
digital_out mogo_mech = digital_out(Brain.ThreeWirePort.E);

// Default geometry constants for correctAndAlign helpers (update to match robot)
double front_distance_offset_x = 0.0;
double front_distance_offset_y = 6.0;
double right_distance_offset_x = 3.0;
double right_distance_offset_y = 2.0;
double reference_wall_x_in = 0.0;
double reference_wall_y_in = 144.0;
double max_pose_correction_shift_in = 2.5;

// ============================================================================
// USER-CONFIGURABLE PARAMETERS (CHANGE BEFORE USING THIS TEMPLATE)
// ============================================================================

// Distance between the middles of the left and right wheels of the drive (in inches)
double distance_between_wheels = 11.28;

// motor to wheel gear ratio * wheel diameter (in inches) * pi
double wheel_distance_in = (36.0 / 48.0) * 3.17 * M_PI;

// PID Constants for movement
// distance_* : Linear PID for straight driving
// turn_*     : PID for turning in place
// heading_correction_* : PID for heading correction during linear movement
double distance_kp = 1.1, distance_ki = 0.1, distance_kd = 7;
double turn_kp = 0.3, turn_ki = 0, turn_kd = 2.5;
double heading_correction_kp = 0.6, heading_correction_ki = 0, heading_correction_kd = 4;

// Enable or disable the use of tracking wheels
bool using_horizontal_tracker = false;  // Set to true if a horizontal tracking wheel is installed and used for odometry
bool using_vertical_tracker = false;   // Set to true if a vertical tracking wheel is installed and used for odometry

// IGNORE THESE IF YOU ARE NOT USING TRACKING WHEELS
// These comments are in the perspective of a top down view of the robot when the robot is facing vertical
// Vertical distance from the center of the bot to the horizontal tracking wheel (in inches, positive is when the wheel is behind the center)
double horizontal_tracker_dist_from_center = 2.71875;
// Horizontal distance from the center of the bot to the vertical tracking wheel (in inches, positive is when the wheel is to the right of the center)
double vertical_tracker_dist_from_center = -0.03125;
double horizontal_tracker_diameter = 1.975; // Diameter of the horizontal tracker wheel (in inches)
double vertical_tracker_diameter = 1.975; // Diameter of the vertical tracker wheel (in inches)

// ============================================================================
// ADVANCED TUNING (OPTIONAL)
// ============================================================================

bool heading_correction = true; // Use heading correction when the bot is stationary

// Set to true for more accuracy and smoothness, false for more speed
bool dir_change_start = true;   // Less accel/decel due to expecting direction change at start of movement
bool dir_change_end = true;     // Less accel/decel due to expecting direction change at end of movement

double min_output = 10; // Minimum output voltage to motors while chaining movements

// Maximum allowed change in voltage output per 10 msec during movement
double max_slew_accel_fwd = 24;
double max_slew_decel_fwd = 24;
double max_slew_accel_rev = 24;
double max_slew_decel_rev = 24;

// Prevents too much slipping during boomerang movements
// Decrease if there is too much drifting and inconsistency during boomerang
// Increase for more speed during boomerang
double chase_power = 2;

// ============================================================================
// DO NOT CHANGE ANYTHING BELOW
// ============================================================================

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void) {
  // nothing to initialize
}
#include "vex.h"
#include "utils.h"
#include "pid.h"
#include <ctime>
#include <cmath>
#include <thread>

#include "../include/autonomous.h"
#include "../include/ball-indexer.h"
#include "../include/robot-config.h"
#include "motor-control.h"

// /*
//  * intakeThread
//  * Runs the intake until an object is detected by the optical or distance sensor, then stops the intake.
//  * Used for picking up rings or other objects during autonomous.
//  */
// void intakeThread(){
//   optical_sensor.setLight(ledState::on);      // Turn on optical sensor light
//   optical_sensor.setLightPower(100);          // Set light power to max
//   while(!optical_sensor.isNearObject() && intake_distance.objectDistance(mm) > 50){
//     wait(10, msec);                           // Wait until object is detected
//   }
//   intake_motor.stop(hold);                    // Stop intake motor and hold
// }

// /*
//  * runIntake
//  * Passive intake helper that keeps the intake running at the requested voltage
//  * and briefly reverses the motor whenever it detects that the shaft has stopped moving.
//  * Call this inside a dedicated task/thread loop during autonomous:
//  *   while(true) runIntake(10);
//  */
 
// void runIntake(double voltage,
//                double stallDeltaDeg,
//                int reverseDurationMs,
//                double reverseVoltage,
//                vex::brakeType stopMode) {
//   if (!last_intake_pos_set) {
//     last_intake_pos_deg = intake_motor.position(deg);
//     last_intake_pos_set = true;
//   }

//   double currentPos = intake_motor.position(deg);
//   bool wantsSpin = fabs(voltage) > 1e-3;
//   bool stalled = wantsSpin && fabs(currentPos - last_intake_pos_deg) < stallDeltaDeg && intake_motor.isSpinning();

//   if (stalled) {
//     auto reverseDir = reverseVoltage >= 0 ? vex::directionType::fwd : vex::directionType::rev;
//     intake_motor.spin(reverseDir, fabs(reverseVoltage), volt);
//     wait(reverseDurationMs, msec);
//   }

//   if (wantsSpin) {
//     auto runDir = voltage >= 0 ? vex::directionType::fwd : vex::directionType::rev;
//     intake_motor.spin(runDir, fabs(voltage), volt);
//   } else {
//     intake_motor.stop(stopMode);
//   }

//   last_intake_pos_deg = currentPos;
//   wait(10, msec);
// }

static double clampVolt(double v) {
  if (v > 12.0) return 12.0;
  if (v < -12.0) return -12.0;
  return v;
}

void spinIntakePair(double intakeVolt, double hoodVolt) {
  intakeMotor.spin(intakeVolt >= 0 ? vex::directionType::fwd : vex::directionType::rev,
                   fabs(intakeVolt), vex::voltageUnits::volt);
  hoodMotor.spin(hoodVolt >= 0 ? vex::directionType::fwd : vex::directionType::rev,
                 fabs(hoodVolt), vex::voltageUnits::volt);
}

void startIntakeCollect(double voltage) {
  double v = clampVolt(voltage);
  spinIntakePair(v, -v);
}

void startIntakeScore(double voltage) {
  double v = clampVolt(voltage);
  spinIntakePair(v, v);
}

void startIntakeOuttake(double voltage) {
  double v = clampVolt(voltage);
  spinIntakePair(-v, -v);
}

void stopIntakeRoller(vex::brakeType stopMode) {
  intakeMotor.stop(stopMode);
  hoodMotor.stop(stopMode);
}

void startIndexerIntake() {
  ball_indexer::resetCounts();
  ball_indexer::enable();
}

void startIndexerOuttake() {
  ball_indexer::startOuttake();
}

void stopIndexer() {
  ball_indexer::disable();
}

void shutdownIndexer() {
  ball_indexer::shutdown();
}

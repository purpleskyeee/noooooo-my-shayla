#include "vex.h"
#include "motor-control.h"
#include "../custom/include/autonomous.h"

// Modify autonomous, driver, or pre-auton code below

void runAutonomous() {
  int auton_selected = 4;
  switch(auton_selected) {
    case 1:
      exampleAuton();
      break;
    case 2:
      exampleAuton2();
      break;  
    case 3:
      redGoalRush();
      break;
    case 4:
      testAuton();
      break; 
    case 5:
      break;
    case 6:
      break;
    case 7:
      break;
    case 8:
      break;
    case 9:
      break;
  }
}

// controller_1 input variables (snake_case)
int ch1, ch2, ch3, ch4;
bool l1, l2, r1, r2;
bool button_a, button_b, button_x, button_y;
bool button_up_arrow, button_down_arrow, button_left_arrow, button_right_arrow;
int chassis_flag = 0;
int MAXVELOCITY = 12800;

void runDriver() {
  stopChassis(coast);
  heading_correction = false;
  while (true) {
    // [-100, 100] for controller stick axis values
    ch1 = controller_1.Axis1.value();
    ch2 = controller_1.Axis2.value();
    ch3 = controller_1.Axis3.value();
    ch4 = controller_1.Axis4.value();

    // true/false for controller button presses
    l1 = controller_1.ButtonL1.pressing();
    l2 = controller_1.ButtonL2.pressing();
    r1 = controller_1.ButtonR1.pressing();
    r2 = controller_1.ButtonR2.pressing();
    button_a = controller_1.ButtonA.pressing();
    button_b = controller_1.ButtonB.pressing();
    button_x = controller_1.ButtonX.pressing();
    button_y = controller_1.ButtonY.pressing();
    button_up_arrow = controller_1.ButtonUp.pressing();
    button_down_arrow = controller_1.ButtonDown.pressing();
    button_left_arrow = controller_1.ButtonLeft.pressing();
    button_right_arrow = controller_1.ButtonRight.pressing();


    bool intakebutnoscore=controller_1.ButtonR1.pressing(); // Check if the intake button is pressed
    bool score=controller_1.ButtonR2.pressing(); // Check if the outtake button is pressed
    bool tonguemechtoggle=controller_1.ButtonL2.pressing(); // tongue
    bool outtake=controller_1.ButtonL1.pressing();

    bool rubberbandtoggle=controller_1.ButtonY.pressing(); // Check if the rubberband toggle button is pressed
    bool middescoretoggle=controller_1.ButtonRight.pressing(); // Check if the middescore toggle button is pressed'
    bool sidedescoretoggle=controller_1.ButtonDown.pressing();
    //bool parking=controller_1.ButtonX.pressing(); // Check if the parking button is pressed
    bool defensing=controller_1.ButtonA.pressing();

    axis3=controller_1.Axis3.position();
    axis1=controller_1.Axis1.position();
    Right_Power=axis3-defensechange*axis1;
    Left_Power=axis3+defensechange*axis1;
    if(Right_Power>128) Right_Power=128;
    if(Right_Power<-128) Right_Power=-128;
    if(Left_Power>128) Left_Power=128;
    if(Left_Power<-128) Left_Power=-128;




    
    
    

    //std::cout<<"Axis Up: " << axis3 << ", Axis Left: " << axis1 << std::endl; // Print axis values for debugging
    // Use the controller axis values to control the motors
    if(intakebutnoscore)
    {
      hoodMotor.spin(vex::directionType::rev, MAXVELOCITY, vex::voltageUnits::mV); // Start hood motor at 128
      intakeMotor.spin(vex::directionType::fwd, MAXVELOCITY, vex::voltageUnits::mV); // Start intake motors at 128
    }
    else if(score)
    {
      hoodMotor.spin(vex::directionType::fwd, MAXVELOCITY, vex::voltageUnits::mV); // Start hood motor at 128
      intakeMotor.spin(vex::directionType::fwd, MAXVELOCITY, vex::voltageUnits::mV); // Start intake motors at 128
    }
    else if(outtake)
    {
      hoodMotor.spin(vex::directionType::rev, MAXVELOCITY, vex::voltageUnits::mV); // Start hood motor at 128
      intakeMotor.spin(vex::directionType::rev, MAXVELOCITY, vex::voltageUnits::mV); // Start intake motors at 128
    }
    else 
    {
      hoodMotor.stop(); // Stop hood motor
      intakeMotor.stop(); // Stop intake motors
    }
    /*
    if(tonguemechtoggle!=lasttonguepressstate)
    {
      if(tonguemechdown) tonguemechdown=false; //false for tongue
      else tonguemechdown=true; //true for tongue
    }
    */

    if(tonguemechtoggle!=lasttonguepressstate)
    {
      if(tonguemechdown) tonguemechdown=false;
      else tonguemechdown=true;
    }

    if(rubberbandtoggle!=lastbandpressstate)
    {
      if(rubberbandon) rubberbandon=false;
      else rubberbandon=true;
    }

    if(middescoretoggle!=lastdescorepressstate)
    {
      if(middescoreon) middescoreon=false;
      else middescoreon=true;
    }

    if(sidedescoretoggle!=lastsiddescorestate)
    {
      if(descoreup) descoreup=false;
      else descoreup=true;
    }

    if(defensing!=lastdefensestate)
    {
      defensechange*=-1;
    }

    lasttonguepressstate=tonguemechtoggle;
    if(tonguemechdown) tonguemech.close(); 
    else tonguemech.open();

    lastbandpressstate=rubberbandtoggle;
    if(rubberbandon) rubberband.close();
    else rubberband.open();

    lastdescorepressstate=middescoretoggle;
    if(middescoreon) middescore.open();
    else middescore.close();

    lastsiddescorestate=sidedescoretoggle;
    if(descoreup) sidedescore.open();
    else sidedescore.close();

    //std::cout<<"Axis Up: " << axis3 << ", Axis Left: " << axis1 << std::endl; // Print axis values for debugging
    // Use the controller axis values to control the motors
    left_chassis.spin(vex::directionType::fwd, 128*defensechange*Left_Power, vex::voltageUnits::mV);
    right_chassis.spin(vex::directionType::fwd, 128*defensechange*Right_Power, vex::voltageUnits::mV);

    wait(10, msec); 
  }
}

void runPreAutonomous() {
    // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  // Calibrate inertial sensor
  inertial_sensor.calibrate();

  // Wait for the Inertial Sensor to calibrate
  while (inertial_sensor.isCalibrating()) {
    wait(10, msec);
  }

  double current_heading = inertial_sensor.heading();
  Brain.Screen.print(current_heading);
  
  // odom tracking
  resetChassis();
  if(using_horizontal_tracker && using_vertical_tracker) {
    thread odom = thread(trackXYOdomWheel);
  } else if (using_horizontal_tracker) {
    thread odom = thread(trackXOdomWheel);
  } else if (using_vertical_tracker) {
    thread odom = thread(trackYOdomWheel);
  } else {
    thread odom = thread(trackNoOdomWheel);
  }
}